import os
import re
import sys
import json
import time
import asyncio
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import whisper
import spacy
import requests
from playwright.async_api import async_playwright


APP_DIR = os.path.abspath(os.path.dirname(__file__))
DEFAULTS_PATH = os.path.join(APP_DIR, "settings.json")

# -------- Settings --------
DEFAULT_SETTINGS = {
    "whisper_model": "base",
    "images_per_keyword": 3,
    "max_keywords": 20,
    "max_total_images": 60,
    "max_scrolls_per_keyword": 6,
    "use_visible_browser": True,
    "use_existing_chrome_profile": False,
    "chrome_profile_dir": "",
}

def load_settings():
    if os.path.exists(DEFAULTS_PATH):
        try:
            with open(DEFAULTS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            merged = dict(DEFAULT_SETTINGS)
            merged.update({k: v for k, v in data.items() if k in DEFAULT_SETTINGS})
            return merged
        except Exception:
            return dict(DEFAULT_SETTINGS)
    return dict(DEFAULT_SETTINGS)

def save_settings(settings: dict):
    with open(DEFAULTS_PATH, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)

# -------- Helpers --------
def safe_folder_name(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9_\- ]+", "", s)
    s = re.sub(r"\s+", "_", s)
    return s[:80] if s else "keyword"

def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def which_browser_executable():
    # Prefer user's installed Chrome/Chromium if present.
    candidates = ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"]
    for c in candidates:
        path = shutil.which(c)
        if path:
            return path
    return None

# -------- SRT generation --------
def format_srt_time(seconds: float) -> str:
    # HH:MM:SS,mmm
    ms = int(round(seconds * 1000))
    h = ms // (3600 * 1000)
    ms -= h * 3600 * 1000
    m = ms // (60 * 1000)
    ms -= m * 60 * 1000
    s = ms // 1000
    ms -= s * 1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def generate_srt(video_path: str, whisper_model_name: str):
    model = whisper.load_model(whisper_model_name)
    result = model.transcribe(video_path)

    srt_dir = os.path.join(APP_DIR, "srt")
    ensure_dir(srt_dir)
    srt_path = os.path.join(srt_dir, "output.srt")

    with open(srt_path, "w", encoding="utf-8") as f:
        for i, seg in enumerate(result["segments"], 1):
            f.write(f"{i}\n")
            f.write(f"{format_srt_time(seg['start'])} --> {format_srt_time(seg['end'])}\n")
            f.write(seg["text"].strip() + "\n\n")

    return srt_path, result.get("text", "")

# -------- Keyword extraction (nouns + proper nouns) --------
def extract_keywords(text: str, max_keywords: int):
    # Lazy-load spaCy model once.
    global _NLP
    if "_NLP" not in globals():
        _NLP = spacy.load("en_core_web_sm")

    doc = _NLP(text)
    freq = {}
    for token in doc:
        if token.is_stop:
            continue
        if token.pos_ not in ("NOUN", "PROPN"):
            continue
        t = token.lemma_.strip().lower()
        if len(t) < 3:
            continue
        if not re.match(r"^[a-z0-9][a-z0-9\-\_ ]*$", t):
            continue
        freq[t] = freq.get(t, 0) + 1

    # Sort by frequency then alphabetically for stability.
    items = sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))
    return [k for k, _ in items[:max_keywords]]

# -------- Google Images scraping via Playwright (real browser window option) --------
async def google_images_download(
    keyword: str,
    out_dir: str,
    images_needed: int,
    max_scrolls: int,
    use_visible_browser: bool,
    use_existing_profile: bool,
    chrome_profile_dir: str,
    status_cb=None,
):
    ensure_dir(out_dir)

    browser_exe = which_browser_executable()

    async with async_playwright() as p:
        # Use persistent context to better mimic "normal browsing"
        # and optionally reuse the user's existing Chrome profile (cookies, etc.)
        launch_args = []
        if use_visible_browser:
            launch_args += ["--start-maximized"]
        else:
            launch_args += ["--disable-gpu"]

        if use_existing_profile and chrome_profile_dir:
            user_data_dir = chrome_profile_dir
        else:
            # Local persistent profile (still more "real" than stateless context)
            user_data_dir = os.path.join(APP_DIR, ".playwright_profile")

        context = await p.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            headless=(not use_visible_browser),
            executable_path=browser_exe,
            args=launch_args,
            viewport=None,
        )

        page = await context.new_page()
        await page.goto("https://www.google.com/imghp?hl=en", wait_until="domcontentloaded")

        # Search
        await page.fill("input[name='q']", keyword)
        await page.keyboard.press("Enter")
        await page.wait_for_load_state("domcontentloaded")
        await page.wait_for_timeout(700)

        seen = set()
        saved = 0

        def set_status(msg):
            if status_cb:
                status_cb(msg)

        set_status(f"Searching images for: {keyword}")

        # Main loop: scroll + click thumbnails to get original URLs
        for scroll_i in range(max_scrolls):
            # Thumbnails currently in DOM
            thumbs = await page.query_selector_all("img.Q4LuWd, img.YQ4gaf, img.rg_i")
            for idx in range(len(thumbs)):
                if saved >= images_needed:
                    break

                thumbs = await page.query_selector_all("img.Q4LuWd, img.YQ4gaf, img.rg_i")
                if idx >= len(thumbs):
                    break

                thumb = thumbs[idx]
                try:
                    await thumb.click(timeout=1500)
                except Exception:
                    continue

                await page.wait_for_timeout(350)

                # In the side panel, Google often uses images with class n3VNCb
                candidates = await page.query_selector_all("img.n3VNCb")
                url = None
                for c in candidates:
                    try:
                        src = await c.get_attribute("src")
                    except Exception:
                        continue
                    if not src:
                        continue
                    if src.startswith("http") and "gstatic.com" not in src:
                        url = src
                        break
                if not url:
                    # fallback: allow gstatic if nothing else
                    for c in candidates:
                        try:
                            src = await c.get_attribute("src")
                        except Exception:
                            continue
                        if src and src.startswith("http"):
                            url = src
                            break

                if not url or url in seen:
                    continue

                seen.add(url)
                filename = os.path.join(out_dir, f"{saved+1:03d}.jpg")
                try:
                    set_status(f"Downloading {saved+1}/{images_needed} for '{keyword}'")
                    r = requests.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
                    if r.status_code == 200 and len(r.content) > 1000:
                        with open(filename, "wb") as f:
                            f.write(r.content)
                        saved += 1
                except Exception:
                    continue

            if saved >= images_needed:
                break

            set_status(f"Scrolling… ({scroll_i+1}/{max_scrolls}) for '{keyword}'")
            await page.mouse.wheel(0, 1200)
            await page.wait_for_timeout(700)

        await context.close()
        return saved

# -------- GUI --------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Auto B‑Roll Generator (SRT → keywords → Google Images)")
        self.geometry("720x520")

        self.settings = load_settings()

        self.video_path = tk.StringVar(value="")
        self.whisper_model = tk.StringVar(value=self.settings["whisper_model"])
        self.images_per_keyword = tk.IntVar(value=self.settings["images_per_keyword"])
        self.max_keywords = tk.IntVar(value=self.settings["max_keywords"])
        self.max_total_images = tk.IntVar(value=self.settings["max_total_images"])
        self.max_scrolls = tk.IntVar(value=self.settings["max_scrolls_per_keyword"])
        self.visible_browser = tk.BooleanVar(value=self.settings["use_visible_browser"])
        self.use_existing_profile = tk.BooleanVar(value=self.settings["use_existing_chrome_profile"])
        self.profile_dir = tk.StringVar(value=self.settings["chrome_profile_dir"])

        self.status = tk.StringVar(value="Ready.")

        self._build_ui()

    def _build_ui(self):
        pad = {"padx": 10, "pady": 6}
        frm = ttk.Frame(self)
        frm.pack(fill="both", expand=True, **pad)

        # Video picker
        row = 0
        ttk.Label(frm, text="Video file:").grid(row=row, column=0, sticky="w")
        ttk.Entry(frm, textvariable=self.video_path, width=58).grid(row=row, column=1, sticky="we")
        ttk.Button(frm, text="Browse…", command=self.pick_video).grid(row=row, column=2, sticky="e")

        # Whisper model selector
        row += 1
        ttk.Label(frm, text="Whisper model:").grid(row=row, column=0, sticky="w")
        model_box = ttk.Combobox(frm, textvariable=self.whisper_model, values=["tiny", "base", "small", "medium", "large"], state="readonly")
        model_box.grid(row=row, column=1, sticky="w")

        # Caps
        row += 1
        ttk.Label(frm, text="Images per keyword:").grid(row=row, column=0, sticky="w")
        ttk.Spinbox(frm, from_=1, to=20, textvariable=self.images_per_keyword, width=10).grid(row=row, column=1, sticky="w")
        row += 1
        ttk.Label(frm, text="Max keywords (cap per SRT):").grid(row=row, column=0, sticky="w")
        ttk.Spinbox(frm, from_=1, to=200, textvariable=self.max_keywords, width=10).grid(row=row, column=1, sticky="w")
        row += 1
        ttk.Label(frm, text="Max total images (overall cap):").grid(row=row, column=0, sticky="w")
        ttk.Spinbox(frm, from_=1, to=5000, textvariable=self.max_total_images, width=10).grid(row=row, column=1, sticky="w")
        row += 1
        ttk.Label(frm, text="Max scrolls per keyword (Google pages):").grid(row=row, column=0, sticky="w")
        ttk.Spinbox(frm, from_=1, to=50, textvariable=self.max_scrolls, width=10).grid(row=row, column=1, sticky="w")

        # Browser options
        row += 1
        ttk.Checkbutton(frm, text="Use visible browser window (more human, fewer blocks)", variable=self.visible_browser).grid(row=row, column=0, columnspan=2, sticky="w")

        row += 1
        ttk.Checkbutton(frm, text="Use my existing Chrome profile (cookies/login)", variable=self.use_existing_profile, command=self._toggle_profile).grid(row=row, column=0, columnspan=2, sticky="w")

        row += 1
        ttk.Label(frm, text="Chrome profile directory:").grid(row=row, column=0, sticky="w")
        self.profile_entry = ttk.Entry(frm, textvariable=self.profile_dir, width=58, state=("normal" if self.use_existing_profile.get() else "disabled"))
        self.profile_entry.grid(row=row, column=1, sticky="we")
        self.profile_btn = ttk.Button(frm, text="Pick…", command=self.pick_profile_dir, state=("normal" if self.use_existing_profile.get() else "disabled"))
        self.profile_btn.grid(row=row, column=2, sticky="e")

        # Action buttons
        row += 1
        ttk.Separator(frm).grid(row=row, column=0, columnspan=3, sticky="we", pady=10)

        row += 1
        ttk.Button(frm, text="Run: SRT → keywords → images", command=self.run_all).grid(row=row, column=0, sticky="w")
        ttk.Button(frm, text="Open output folder", command=self.open_output).grid(row=row, column=1, sticky="w")
        ttk.Button(frm, text="Save settings", command=self.save_current_settings).grid(row=row, column=2, sticky="e")

        # Status + log
        row += 1
        ttk.Label(frm, text="Status:").grid(row=row, column=0, sticky="nw")
        self.log = tk.Text(frm, height=10)
        self.log.grid(row=row, column=1, columnspan=2, sticky="nsew")
        frm.rowconfigure(row, weight=1)
        frm.columnconfigure(1, weight=1)

        row += 1
        ttk.Label(frm, textvariable=self.status).grid(row=row, column=0, columnspan=3, sticky="we")

    def _toggle_profile(self):
        enabled = self.use_existing_profile.get()
        self.profile_entry.config(state=("normal" if enabled else "disabled"))
        self.profile_btn.config(state=("normal" if enabled else "disabled"))

    def log_line(self, msg: str):
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.update_idletasks()

    def set_status(self, msg: str):
        self.status.set(msg)
        self.log_line(msg)

    def pick_video(self):
        p = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.mkv *.mov *.m4v *.webm"), ("All files", "*.*")])
        if p:
            self.video_path.set(p)

    def pick_profile_dir(self):
        p = filedialog.askdirectory()
        if p:
            self.profile_dir.set(p)

    def open_output(self):
        # Open output folders in file manager (Linux-friendly)
        out = os.path.join(APP_DIR, "images")
        ensure_dir(out)
        try:
            if sys.platform.startswith("linux"):
                os.system(f'xdg-open "{out}" >/dev/null 2>&1 &')
            elif sys.platform == "darwin":
                os.system(f'open "{out}" >/dev/null 2>&1 &')
            elif sys.platform.startswith("win"):
                os.startfile(out)  # type: ignore
        except Exception:
            pass

    def save_current_settings(self):
        s = {
            "whisper_model": self.whisper_model.get(),
            "images_per_keyword": int(self.images_per_keyword.get()),
            "max_keywords": int(self.max_keywords.get()),
            "max_total_images": int(self.max_total_images.get()),
            "max_scrolls_per_keyword": int(self.max_scrolls.get()),
            "use_visible_browser": bool(self.visible_browser.get()),
            "use_existing_chrome_profile": bool(self.use_existing_profile.get()),
            "chrome_profile_dir": self.profile_dir.get(),
        }
        save_settings(s)
        self.set_status("Settings saved.")

    def run_all(self):
        video = self.video_path.get().strip()
        if not video or not os.path.exists(video):
            messagebox.showerror("Missing video", "Pick a valid video file first.")
            return

        # Persist settings immediately
        self.save_current_settings()

        try:
            self.set_status("Generating SRT with Whisper…")
            srt_path, text = generate_srt(video, self.whisper_model.get())
            self.set_status(f"SRT saved: {srt_path}")

            self.set_status("Extracting keywords (nouns/proper nouns)…")
            keywords = extract_keywords(text, int(self.max_keywords.get()))
            self.set_status(f"Keywords extracted (capped): {len(keywords)}")

            images_root = os.path.join(APP_DIR, "images")
            ensure_dir(images_root)

            per_kw = int(self.images_per_keyword.get())
            max_total = int(self.max_total_images.get())
            max_scrolls = int(self.max_scrolls.get())

            total_saved = 0
            for kw in keywords:
                if total_saved >= max_total:
                    self.set_status(f"Reached max total images cap ({max_total}). Stopping.")
                    break

                remaining = max_total - total_saved
                need = min(per_kw, remaining)

                out_dir = os.path.join(images_root, safe_folder_name(kw))
                self.set_status(f"Keyword '{kw}': downloading up to {need} images…")

                saved = asyncio.run(
                    google_images_download(
                        keyword=kw,
                        out_dir=out_dir,
                        images_needed=need,
                        max_scrolls=max_scrolls,
                        use_visible_browser=bool(self.visible_browser.get()),
                        use_existing_profile=bool(self.use_existing_profile.get()),
                        chrome_profile_dir=self.profile_dir.get().strip(),
                        status_cb=self.set_status,
                    )
                )

                total_saved += saved
                self.set_status(f"Saved {saved} images for '{kw}' (total {total_saved}).")

            self.set_status("Done. SRT + keyword folders + images created.")
            messagebox.showinfo("Done", "Finished generating SRT and downloading images.")

        except Exception as e:
            self.set_status(f"Error: {e}")
            messagebox.showerror("Error", str(e))


if __name__ == "__main__":
    App().mainloop()
